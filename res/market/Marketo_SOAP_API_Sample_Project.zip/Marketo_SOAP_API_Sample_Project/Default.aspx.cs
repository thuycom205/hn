﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;

namespace Marketo_SOAP_API_Sample_Project
{
    public partial class Default : System.Web.UI.Page
    {

        // Added a reference to the Marketo Service to the ASP.NET project by right clicking on the project and selecting Add Service Reference
        //Endpoint can be found here - MLM->Admin->SOAP API->SOAP Endpoint (be sure to postfix with ?WSDL)
        
        // For example this Project points to the following Service Reference https://na-b.marketo.com/soap/mktows/1_7?WSDL

        // You can also modify the endpoint address used in this example by changing it in the web.config
        // <client>
        //     <endpoint address="https://na-b.marketo.com/soap/mktows/1_7"
        //         binding="basicHttpBinding" bindingConfiguration="MktowsApiSoapBinding"
        //         contract="Marketo_WS.MktowsPort" name="MktowsApiSoapPort" />
        // </client>

        private Marketo_WS.MktowsPortClient client = new Marketo_WS.MktowsPortClient();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region User Clicked Get Leads
        protected void btnGetLeads_Click(object sender, EventArgs e)
        {
            #region make the GetLeads Call
            string leadKey = txtLeadID.Text;

            Marketo_WS.ResultGetLead resultGetLead = new Marketo_WS.ResultGetLead();

            string result = GetLeads(leadKey, ref resultGetLead);
            #endregion

            #region Display the Lead info on the screen


            lblResult.Text = "";

            string allLeads = "";

            if (result.Length > 0)
            {
                allLeads = result;
            }
            else if (resultGetLead.count == 0)
            {
                allLeads = "No Lead(s) Found";
            }
            else
            {
                Marketo_WS.LeadRecord[] leadRecs = resultGetLead.leadRecordList;

                allLeads = "";

                foreach (Marketo_WS.LeadRecord leadRecord in leadRecs)
                {
                    allLeads = allLeads + @"<br/><b>" + leadRecord.Email + @"</b><br/>";
                    foreach (Marketo_WS.Attribute attrib in leadRecord.leadAttributeList)
                    {
                        allLeads = allLeads + attrib.attrName + " - " + attrib.attrValue + @"<br/>";
                    }
                }

            }



            lblResult.Text = allLeads;
            #endregion
        }
        #endregion

        #region Get Leads
        private string GetLeads(string LeadID, ref Marketo_WS.ResultGetLead rs)
        {
            Marketo_WS.SuccessGetLead response = new Marketo_WS.SuccessGetLead();

            string results = "";

            string userID = txtUserID.Text;
            string EncryptionKey = txtEncryptionID.Text;



            string requestTimeStamp = ConvertDateToW3CTime(DateTime.Now);

            string stringToEncrypt = requestTimeStamp + userID;


            string message;
            string key;

            key = EncryptionKey;
            message = stringToEncrypt;

            System.Text.ASCIIEncoding encoding = new System.Text.ASCIIEncoding();

            byte[] keyByte = encoding.GetBytes(key);

            HMACSHA1 hmacsha1 = new HMACSHA1(keyByte);

            byte[] messageBytes = encoding.GetBytes(message);

            byte[] hashmessage = hmacsha1.ComputeHash(messageBytes);

            string header = ByteToString(hashmessage);



            Marketo_WS.AuthenticationHeaderInfo ws_header = new Marketo_WS.AuthenticationHeaderInfo();
            ws_header.mktowsUserId = userID;
            ws_header.requestSignature = header.ToLower();
            ws_header.requestTimestamp = requestTimeStamp;

            Marketo_WS.ParamsGetLead ws_lead = new Marketo_WS.ParamsGetLead();
            Marketo_WS.LeadKey ws_leadkey = new Marketo_WS.LeadKey();
            ws_leadkey.keyType = Marketo_WS.LeadKeyRef.IDNUM;
            ws_leadkey.keyValue = LeadID;
            ws_lead.leadKey = ws_leadkey;



            try
            {
                response = client.getLead(ws_header, ws_lead);
                results = "";
                rs = response.result;
            }
            catch (Exception e)
            {
                results = e.Message;
                rs = null;
            }


            return results;
        }
        #endregion

        #region supporting Functions
        public static string ByteToString(byte[] buff)
        {
            string sbinary = "";

            for (int i = 0; i < buff.Length; i++)
            {
                sbinary += buff[i].ToString("X2"); // hex format
            }
            return (sbinary);
        }


        public static string HashCode(string str)
        {
            string rethash = "";
            try
            {

                System.Security.Cryptography.SHA1 hash = System.Security.Cryptography.SHA1.Create();
                System.Text.ASCIIEncoding encoder = new System.Text.ASCIIEncoding();
                byte[] combined = encoder.GetBytes(str);
                hash.ComputeHash(combined);
                rethash = Convert.ToBase64String(hash.Hash);
            }
            catch (Exception ex)
            {
                string strerr = "Error in HashCode : " + ex.Message;
            }
            return rethash;
        }


        public static string ConvertDateToW3CTime(DateTime date)
        {
            var utcOffset = TimeZone.CurrentTimeZone.GetUtcOffset(date);
            string w3CTime = date.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss");
            w3CTime += utcOffset == TimeSpan.Zero ? "Z" :
                String.Format("{0}{1:00}:{2:00}", (utcOffset > TimeSpan.Zero ? "+" : "-")
                , Math.Abs(utcOffset.Hours), utcOffset.Minutes);

            //w3CTime += utcOffset == TimeSpan.Zero ? "Z" :
            //    String.Format("{0}{1:00}:{2:00}", (utcOffset > TimeSpan.Zero ? "+" : "-")
            //    , utcOffset.Hours, utcOffset.Minutes);
            return w3CTime;
        }
        #endregion

    }
}