package com.marketo.mktows.test;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;


import com.marketo.mktows.client.MktServiceException;
import com.marketo.mktows.client.MktowsClient;
import com.marketo.mktows.client.MktowsClientException;
import com.marketo.mktows.client.MktowsUtil;
import com.marketo.mktows.client.StreamPostionHolder;
import com.marketo.mktows.wsdl.ActivityRecord;
import com.marketo.mktows.wsdl.ActivityType;
import com.marketo.mktows.wsdl.ArrayOfAttribute;
import com.marketo.mktows.wsdl.ArrayOfInteger;
import com.marketo.mktows.wsdl.Attribute;
import com.marketo.mktows.wsdl.CampaignRecord;
import com.marketo.mktows.wsdl.LeadChangeRecord;
import com.marketo.mktows.wsdl.LeadKey;
import com.marketo.mktows.wsdl.LeadKeyRef;
import com.marketo.mktows.wsdl.LeadMergeStatusEnum;
import com.marketo.mktows.wsdl.LeadRecord;
import com.marketo.mktows.wsdl.LeadSyncStatus;
import com.marketo.mktows.wsdl.MergeStatus;
import com.marketo.mktows.wsdl.ResultSyncLead;
import com.marketo.mktows.wsdl.SyncStatus;

public class TestMktows {
	
	protected MktowsClient client = null;
	
	public TestMktows() {
		
		client = new MktowsClient(TestMktows.ACCESS_KEY, TestMktows.SECRET_KEY, TestMktows.HOST_NAME);
	}

	public static final String HOST_NAME = "localhost";
	public static final String ACCESS_KEY = "bigcorp1_543653174CEC4191431E50";
	public static final String SECRET_KEY = "QRSTUVWXYZQ1";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		TestMktows tester = new TestMktows();
//		tester.testGetLead();
//		tester.testGetLeadActivity();
//		tester.testGetLeadChanges();
//		tester.testGetMultipleLeads();
//		tester.testGetMultipleLeadsUnsubscribedFlag();
//		tester.testSyncLead();
//		tester.testSyncMultipleLeads();
//		tester.testGetCampaignsForSource();
//		tester.testRequestCampaign();
//		tester.testListMObjects();
		tester.testMergeLeads();
	}
	
	public void testGetCampaignsForSource() {
		
		List<CampaignRecord> campaignRecords = this.client.getCampaignsForSource();
		if (campaignRecords != null) {
			for(CampaignRecord item : campaignRecords) {
				System.out.println("Campaign name: " + item.getName() + ",  ID: " + item.getId());
			}
		}
	}
	
	public void testGetLead() {
		
		List<LeadRecord> leadRecords = null;
		try {
			leadRecords = this.client.getLead(LeadKeyRef.EMAIL, "scoobyzz@marketo.com");
		}
		catch (MktServiceException e) {
			System.out.println("Exception occurred: " + e.getLongMessage());
			return;
		}
		if (leadRecords != null) {
			Map<String, Object> attrMap = null;
			for(LeadRecord item : leadRecords) {
				System.out.println("Lead Id: " + item.getId() + ",  Email: " + item.getEmail());
				ArrayOfAttribute aoAttribute = item.getLeadAttributeList();
				if (aoAttribute != null) {
					attrMap = MktowsUtil.getLeadAttributeMap(aoAttribute);
					if (attrMap != null && !attrMap.isEmpty()) {
						Set<String> keySet = attrMap.keySet();
						for (String key : keySet) {
							System.out.println("    Attribute name: " + key + ", value: " + attrMap.get(key).toString());
						}
					}
				}
			}
		}
	}
	
	public void testRequestCampaign() {
		
		final String myCampName = "Product Seminar - Summer"; 
		final String leadEmail = "scooby1@marketo.com";
		// Find the available campaigns
		List<CampaignRecord> campaignRecords = this.client.getCampaignsForSource();
		int myCampId = 0;
		if (campaignRecords != null) {
			// Find ID for campaign of interest
			for(CampaignRecord item : campaignRecords) {
				if (item.getName() == myCampName) {
					myCampId = item.getId();
					break;
				}
			}
		}
	
		if (myCampId == 0) {
			System.out.println("Campaign not found: " + myCampName);
			return;
		}
		
		// Find the lead ID for lead(s) that need to be added to the campaign
		List<LeadRecord> leadRecords = null;
		try {
			leadRecords = this.client.getLead(LeadKeyRef.EMAIL, leadEmail);
		}
		catch (MktServiceException e) {
			System.out.println("Exception occurred: " + e.getMessage());
			return;
		}
		int leadId = 0;
		if (leadRecords != null) {
			for(LeadRecord item : leadRecords) {
				leadId = item.getId();
				break;
			}
		}
		
		if (leadId == 0) {
			System.out.println("Lead not found: " + leadEmail);
			return;
		}
		
		// Request that lead(s) be added to the campaign
		LeadKey leadKey = MktowsUtil.objectFactory.createLeadKey();
		leadKey.setKeyType(LeadKeyRef.IDNUM);
		leadKey.setKeyValue(new Integer(leadId).toString());
		List<LeadKey> leadList = new ArrayList<LeadKey>();
		leadList.add(leadKey);
		boolean success = this.client.requestCampaign(myCampId, leadList);
		if (success) {
			System.out.println("Lead " + leadId + " added to campaign " + myCampName);
		}
		else {
			System.out.println("Failed to add lead " + leadId + " to campaign " + myCampName);
		}
	}
	
	public void testGetLeadActivity() {
		
		StreamPostionHolder posHolder = new StreamPostionHolder();
		Date lastestCreatedAt = new Date();
		List<ActivityType> filter = new ArrayList<ActivityType>();
		filter.add(ActivityType.VISIT_WEBPAGE);
		filter.add(ActivityType.FILL_OUT_FORM);
		filter.add(ActivityType.OPEN_EMAIL);
		filter.add(ActivityType.OPEN_SALES_EMAIL);
		filter.add(ActivityType.CLICK_EMAIL);
		filter.add(ActivityType.CLICK_SALES_EMAIL);
		filter.add(ActivityType.NEW_LEAD);
		List<ActivityRecord> activityRecords = null;
		try {
			activityRecords = this.client.getLeadActivity(LeadKeyRef.IDNUM, "24", 10, lastestCreatedAt, null, filter, posHolder);
		}
		catch (MktowsClientException e) {
			e.printStackTrace();
			return;
		}
		catch (MktServiceException e) {
			e.printStackTrace();
			return;
		}
		if (activityRecords != null) {
			Map<String, Object> attrMap = null;
			for(ActivityRecord item : activityRecords) {
				String wsdlTS = item.getActivityDateTime().toString();
				Date localDT =  MktowsUtil.w3cDateToDateObject(item.getActivityDateTime());
				DateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String localTS = fmt.format(localDT);
				System.out.println("Activity: " + item.getActivityType() + ",  WSDL Timestamp: " + wsdlTS + ",  LOCAL Timestamp: " + localTS);
				ArrayOfAttribute aoAttribute = item.getActivityAttributes();
				if (aoAttribute != null) {
					attrMap = MktowsUtil.getLeadAttributeMap(aoAttribute);
					if (attrMap != null && !attrMap.isEmpty()) {
						Set<String> keySet = attrMap.keySet();
						for (String key : keySet) {
							System.out.println("    Attribute name: " + key + ", value: " + attrMap.get(key).toString());
						}
					}
				}
			}
		}
	}

	public void testGetLeadChanges() {
		
		StreamPostionHolder posHolder = new StreamPostionHolder();
		Calendar cal = new GregorianCalendar(2010, Calendar.MAY, 1, 0, 0, 0);
		Date oldestCreatedAt = cal.getTime();
		List<ActivityType> filter = new ArrayList<ActivityType>();
		filter.add(ActivityType.VISIT_WEBPAGE);
		filter.add(ActivityType.FILL_OUT_FORM);
		filter.add(ActivityType.OPEN_EMAIL);
		filter.add(ActivityType.OPEN_SALES_EMAIL);
		filter.add(ActivityType.CLICK_EMAIL);
		filter.add(ActivityType.CLICK_SALES_EMAIL);
		filter.add(ActivityType.NEW_LEAD);
		List<LeadChangeRecord> leadChangeRecords = null;
		try {
			leadChangeRecords = this.client.getLeadChanges(100, null, oldestCreatedAt, filter, posHolder);
		}
		catch (MktowsClientException e) {
			e.printStackTrace();
			return;
		}
		if (leadChangeRecords != null) {
			Map<String, Object> attrMap = null;
			for(LeadChangeRecord item : leadChangeRecords) {
				String wsdlTS = item.getActivityDateTime().toString();
				Date localDT =  MktowsUtil.w3cDateToDateObject(item.getActivityDateTime());
				DateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String localTS = fmt.format(localDT);
				System.out.println("Lead: "  +item.getId() + ",  Activity: " + item.getActivityType() + ",  WSDL Timestamp: " + wsdlTS + ",  LOCAL Timestamp: " + localTS);
				ArrayOfAttribute aoAttribute = item.getActivityAttributes();
				if (aoAttribute != null) {
					attrMap = MktowsUtil.getLeadAttributeMap(aoAttribute);
					if (attrMap != null && !attrMap.isEmpty()) {
						Set<String> keySet = attrMap.keySet();
						for (String key : keySet) {
							System.out.println("    Attribute name: " + key + ", value: " + attrMap.get(key).toString());
						}
					}
				}
			}
		}
	}
	
	public void testGetMultipleLeads() {
		
		StreamPostionHolder posHolder = new StreamPostionHolder();
		Calendar cal = new GregorianCalendar(2010, Calendar.MAY, 1, 0, 0, 0);
		Date lastUpdatedAt = cal.getTime();
		List<LeadRecord> leadRecords = null;
		try {
			leadRecords = this.client.getMultipleLeads(100, lastUpdatedAt, posHolder);
		}
		catch (MktowsClientException e) {
			e.printStackTrace();
			return;
		}
		if (leadRecords != null) {
			Map<String, Object> attrMap = null;
			for(LeadRecord item : leadRecords) {
				System.out.println("Lead Id: " + item.getId() + ",  Email: " + item.getEmail());
				ArrayOfAttribute aoAttribute = item.getLeadAttributeList();
				if (aoAttribute != null) {
					attrMap = MktowsUtil.getLeadAttributeMap(aoAttribute);
					if (attrMap != null && !attrMap.isEmpty()) {
						Set<String> keySet = attrMap.keySet();
						for (String key : keySet) {
							System.out.println("    Attribute name: " + key + ", value: " + attrMap.get(key).toString());
						}
					}
				}
			}
		}
	}
	
	public void testGetMultipleLeadsUnsubscribedFlag() {
		
		StreamPostionHolder posHolder = new StreamPostionHolder();
		Calendar cal = new GregorianCalendar(2010, Calendar.MAY, 1, 0, 0, 0);
		Date lastUpdatedAt = cal.getTime();
		List<String> leadAttrs = new ArrayList<String>();
		leadAttrs.add("Unsubscribed");
		leadAttrs.add("UnsubscribedReason");
		List<LeadRecord> leadRecords = null;
		try {
			leadRecords = this.client.getMultipleLeads(100, lastUpdatedAt, posHolder, leadAttrs);
		}
		catch (MktowsClientException e) {
			e.printStackTrace();
			return;
		}
		if (leadRecords != null) {
			Map<String, Object> attrMap = null;
			for(LeadRecord item : leadRecords) {
				System.out.println("Lead Id: " + item.getId() + ",  Email: " + item.getEmail());
				ArrayOfAttribute aoAttribute = item.getLeadAttributeList();
				if (aoAttribute != null) {
					attrMap = MktowsUtil.getLeadAttributeMap(aoAttribute);
					if (attrMap != null && !attrMap.isEmpty()) {
						Set<String> keySet = attrMap.keySet();
						for (String key : keySet) {
							System.out.println("    Attribute name: " + key + ", value: " + attrMap.get(key).toString());
						}
					}
				}
			}
		}
	}
	
	public void testSyncLead() {
		
		HashMap<String, String> attrs = new HashMap<String, String>();
		attrs.put("FirstName", "Sam");
		attrs.put("LastName", "Haggy");
		LeadRecord leadRec = MktowsUtil.newLeadRecord(null, "shaggy@marketo.com", null, null, attrs);
		ResultSyncLead result = client.syncLead(leadRec, null, true);
		leadRec = result.getLeadRecord();
		SyncStatus sts = result.getSyncStatus();
		if (sts.getStatus() == LeadSyncStatus.CREATED) {
			System.out.println("Lead CREATED with Id " + sts.getLeadId());
		}
		else if (sts.getStatus() == LeadSyncStatus.UPDATED) {
			System.out.println("Lead UPDATED with Id " + sts.getLeadId());
		}
		else {
			System.out.println("Unexpected lead sync status");
		}
 	}
	
	public void testSyncMultipleLeads() {
		
		List<LeadRecord> leadRecList = new ArrayList<LeadRecord>();
		Date dt = new Date();
		for (int i=1; i <= 3; ++i) {
			HashMap<String, String> attrs = new HashMap<String, String>();
			attrs.put("FirstName", "FName"+ dt + i);
			attrs.put("LastName", "LName" + dt + i);
			LeadRecord leadRec = MktowsUtil.newLeadRecord(null, "testemail" + dt + i + "@marketo.com", null, null, attrs);
			leadRecList.add(leadRec);
		}
		List<SyncStatus> syncStsList = client.syncMultipleLeads(leadRecList, true);
		for (SyncStatus sts : syncStsList) {
			if (sts.getStatus() == LeadSyncStatus.CREATED) {
				System.out.println("Lead CREATED with Id " + sts.getLeadId());
			}
			else if (sts.getStatus() == LeadSyncStatus.UPDATED) {
				System.out.println("Lead UPDATED with Id " + sts.getLeadId());
			}
			else {
				System.out.println("Unexpected lead sync status");
			}
		}
	}
	
	public void testListMObjects() {
		
		List<String> objectNames = this.client.listMObjects();
		for(String name: objectNames) {
			System.out.println("Object name: " + name);
		}
	}
	
	public void testMergeLeads() {
	    
	    String ID_ATTR = "FOOID"; // Lookup attribute name
	    // The winning lead
	    List<Attribute> winningLead = new ArrayList<Attribute>();
	    winningLead.add(MktowsUtil.newAttribute(ID_ATTR, "1830856327"));
        
        // The losing leads
        List<List<Attribute>> losingLeadList = new ArrayList<List<Attribute>>();
        List<Attribute> loser = new ArrayList<Attribute>();
        // Lead 1
        loser = new ArrayList<Attribute>();
        loser.add(MktowsUtil.newAttribute(ID_ATTR, "1856585834"));
        losingLeadList.add(loser);
        // Lead 2
        loser = new ArrayList<Attribute>();
        loser.add(MktowsUtil.newAttribute(ID_ATTR, "1826211038"));
        losingLeadList.add(loser);
        
        MergeStatus status = this.client.mergeLeads(winningLead, losingLeadList);
        if (status.getStatus() == LeadMergeStatusEnum.MERGED) {
            System.out.println("Winning lead Id " + status.getWinningLeadId());
            List<Integer> loserIds = status.getLosingLeadIdList().getIntegerItem();
            for (Integer intItem : loserIds) {
                System.out.println("Losing leads Id " + intItem);
            }
        }
        else {
            System.out.println("Lead merge status is " + status.getStatus());
            System.out.println("Error: " + status.getError());
        }
	}
}
