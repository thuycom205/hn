@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.marketo.com/mktows/")
package com.marketo.mktows.wsdl;
